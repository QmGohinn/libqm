#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include "mycmd.h"

int main()
{
	int fd;char  buf[20] = {0};int len;
	fd = open("/dev/hello", O_RDWR);
	if(fd < 0 )
	{ 
		printf("error\n");
		return -1;
	}
	while(1){

	ioctl(fd, PLAY_TONE, 262);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 262);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 392);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 392);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 440);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 440);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 392);
	usleep(900000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 349);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 349);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 330);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 330);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 294);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 294);
	usleep(500000);
	ioctl(fd, PLAY_STOP);

	ioctl(fd, PLAY_TONE, 262);
	usleep(500000);
	ioctl(fd, PLAY_STOP);    //little star
	
	sleep(30000000);
	
	}
	
	close(fd);
	return 0;
	
}
